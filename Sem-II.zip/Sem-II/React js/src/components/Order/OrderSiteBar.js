import React from 'react'
import { Row, Col} from 'react-bootstrap'

export default function orderSite() {
return (
<React.Fragment>
    {/* <Row>
        <Col style={{marginLeft:"-400px",padding:"25px 0px 10px 18px"}}><span style={{color:"DarkGray"}}></span></Col>
    </Row>
    <hr /> */}
    {/* <Row>
        <Col style={{padding:"25px 0px 10px 18px"}}>
            <p  style={{color:"DarkGray"}}>ORDERS</p>
            <p style={{ color: "MediumSpringGreen" }}><b>Orders & Returns</b></p>
        </Col>
    </Row> */}
    {/* <hr /> */}
    {/* <Row>
        <Col style={{padding:"25px 0px 10px 18px"}}>
            <p style={{color:"DarkGray"}}></p>
            <span></span><br/>
            <span></span><br />
            <span></span>
        </Col>
    </Row>
    <hr />
    <Row>
        <Col style={{padding:"25px 0px 10px 18px"}}>
            <p style={{color:"DarkGray"}}></p>
            <span></span><br />
            <span></span><br />
            <span></span><br />
            <span></span>
        </Col>
    </Row> */}
</React.Fragment>            
)
}            